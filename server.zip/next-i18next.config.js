module.exports = {
	i18n: {
		defaultLocale: 'vi',
		locales: ['en', 'vi'],
	},
};
