(() => {
var exports = {};
exports.id = 459;
exports.ids = [459];
exports.modules = {

/***/ 8945:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages_login),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "next-i18next/serverSideTranslations"
var serverSideTranslations_ = __webpack_require__(3295);
// EXTERNAL MODULE: ./src/api/authApi.js
var authApi = __webpack_require__(1606);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: external "antd"
var external_antd_ = __webpack_require__(953);
// EXTERNAL MODULE: ./src/services/cookies.js
var cookies = __webpack_require__(5315);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./src/components/login/loginForm.module.scss
var loginForm_module = __webpack_require__(2894);
var loginForm_module_default = /*#__PURE__*/__webpack_require__.n(loginForm_module);
;// CONCATENATED MODULE: ./src/components/login/loginForm.tsx











const LoginForm = () => {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)();
  const router = (0,router_.useRouter)();
  const {
    0: email,
    1: setEmail
  } = (0,external_react_.useState)('');
  const {
    0: password,
    1: setPassword
  } = (0,external_react_.useState)('');

  const onLogin = () => {
    authApi/* default.loginApi */.Z.loginApi({
      email,
      password
    }).then(res => {
      if (res.data.success) {
        const options = res.data.expires_at ? {
          path: '/',
          expires: new Date(res.data.expires_at)
        } : {
          path: '/'
        };
        cookies/* default.set */.Z.set('access_token', res.data.access_token, options);
        cookies/* default.set */.Z.set('token_type', res.data.token_type, options);
        window.localStorage.setItem('userInfo', JSON.stringify(res.data.data));
      } else {
        external_antd_.notification.error({
          message: t('common:notification'),
          description: res.data.message
        });
      }

      return res;
    }).then(res => {
      if (res.data.success) {
        router.push('/setting');
        external_antd_.notification.success({
          message: t('common:notification'),
          description: t('common:loginSuccess')
        });
      }
    }).catch(err => {
      external_antd_.notification.error({
        message: t('common:notification'),
        description: "t('common:loginError')"
      });
      console.log(err);
    });
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: `${(loginForm_module_default())["login-form"]}`,
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      id: "LoginForm",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: `${(loginForm_module_default())["login-form__row"]}`,
        children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
          className: `${(loginForm_module_default())["login-form__label"]}`,
          children: t('common:email')
        }), /*#__PURE__*/jsx_runtime_.jsx("input", {
          value: email,
          onChange: e => setEmail(e.target.value),
          type: "email",
          name: "Email",
          className: `${(loginForm_module_default())["login-form__input"]}`
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: `${(loginForm_module_default())["login-form__row"]}`,
        children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
          className: `${(loginForm_module_default())["login-form__label"]}`,
          children: t('common:password')
        }), /*#__PURE__*/jsx_runtime_.jsx("input", {
          value: password,
          onChange: e => setPassword(e.target.value),
          type: "password",
          name: "password",
          className: `${(loginForm_module_default())["login-form__input"]}`
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: `${(loginForm_module_default())["login-form__row"]}`,
        children: /*#__PURE__*/jsx_runtime_.jsx("input", {
          type: "submit",
          name: "submit",
          className: `${(loginForm_module_default())["login-form__submit"]}`,
          id: "submit",
          value: t('common:login').toString(),
          onClick: () => onLogin()
        })
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: `${(loginForm_module_default())["login-form__bottom"]}`,
      children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
        children: t('common:dontHaveAccount')
      }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
        href: "/signup",
        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
          className: `${(loginForm_module_default())["button-signup"]}`,
          children: t('common:signup')
        })
      })]
    })]
  });
};

/* harmony default export */ const loginForm = (LoginForm);
// EXTERNAL MODULE: ./src/templates/login/login.module.scss
var login_module = __webpack_require__(5330);
var login_module_default = /*#__PURE__*/__webpack_require__.n(login_module);
;// CONCATENATED MODULE: ./src/templates/login/index.tsx








const HOST = "https://linkt.ooo/";

const LoginTemplate = () => {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)();
  const router = (0,router_.useRouter)();
  (0,external_react_.useEffect)(() => {
    checkLogin();
  }, []);

  const checkLogin = () => {
    authApi/* default.getProfileApi */.Z.getProfileApi().then(res => {
      if (res.data.success) {
        router.push('/setting');
      }
    }).catch(err => {
      console.log(err);
    });
  };

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: `${(login_module_default())["page--login"]}`,
    "data-page": "login",
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: `${(login_module_default()).login}`,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: `${(login_module_default()).login__content}`,
        children: [/*#__PURE__*/jsx_runtime_.jsx("img", {
          src: HOST + '/images/linkt000-full.png',
          className: `${(login_module_default())["logo-full"]}`
        }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
          className: `${(login_module_default()).login__title}`,
          children: t('common:welcome')
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: `${(login_module_default()).login__text}`,
          children: t('common:loginToAccount')
        }), /*#__PURE__*/jsx_runtime_.jsx(loginForm, {})]
      })
    })
  });
};

/* harmony default export */ const login = (LoginTemplate);
;// CONCATENATED MODULE: ./pages/login/index.tsx


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





const Login = () => {
  return /*#__PURE__*/jsx_runtime_.jsx((external_react_default()).Fragment, {
    children: /*#__PURE__*/jsx_runtime_.jsx(login, {})
  });
};

const getServerSideProps = async ({
  locale
}) => ({
  props: _objectSpread({}, await (0,serverSideTranslations_.serverSideTranslations)(locale, ["common"]))
});
/* harmony default export */ const pages_login = (Login);

/***/ }),

/***/ 2894:
/***/ ((module) => {

// Exports
module.exports = {
	"login-form": "loginForm_login-form__1klnm",
	"login-form__row": "loginForm_login-form__row__3lXyQ",
	"login-form__label": "loginForm_login-form__label__u46n1",
	"login-form__input": "loginForm_login-form__input__350OT",
	"login-form__submit": "loginForm_login-form__submit__8D-77",
	"login-form__bottom": "loginForm_login-form__bottom__3lGht",
	"button-signup": "loginForm_button-signup__3w7Vv"
};


/***/ }),

/***/ 5330:
/***/ ((module) => {

// Exports
module.exports = {
	"page--login": "login_page--login__1HfUH",
	"login": "login_login__2QBsr",
	"login__content": "login_login__content__190Dg",
	"logo-full": "login_logo-full__311rJ",
	"login__title": "login_login__title__1eDpA",
	"login__text": "login_login__text__30oRI"
};


/***/ }),

/***/ 953:
/***/ ((module) => {

"use strict";
module.exports = require("antd");

/***/ }),

/***/ 2376:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 8475:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next");

/***/ }),

/***/ 3295:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 9325:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8300:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6731:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 9297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 5282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 8993:
/***/ ((module) => {

"use strict";
module.exports = require("universal-cookie");

/***/ }),

/***/ 2431:
/***/ (() => {

/* (ignored) */

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [426,664,606], () => (__webpack_exec__(8945)));
module.exports = __webpack_exports__;

})();