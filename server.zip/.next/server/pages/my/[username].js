(() => {
var exports = {};
exports.id = 627;
exports.ids = [627];
exports.modules = {

/***/ 629:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _username_),
  "getStaticPaths": () => (/* binding */ getStaticPaths),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "antd"
var external_antd_ = __webpack_require__(953);
;// CONCATENATED MODULE: external "@ant-design/icons"
const icons_namespaceObject = require("@ant-design/icons");
var icons_default = /*#__PURE__*/__webpack_require__.n(icons_namespaceObject);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(701);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: ./src/templates/my-links/my-links.module.scss
var my_links_module = __webpack_require__(9349);
var my_links_module_default = /*#__PURE__*/__webpack_require__.n(my_links_module);
// EXTERNAL MODULE: ./src/themes/index.module.scss
var index_module = __webpack_require__(2122);
var index_module_default = /*#__PURE__*/__webpack_require__.n(index_module);
;// CONCATENATED MODULE: ./src/templates/my-links/index.tsx










const {
  Footer
} = external_antd_.Layout;
const HOST = "https://linkt.ooo/";
const MyLinksTemplate = ({
  linksData,
  socialsData,
  profileData
}) => {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)();
  const {
    0: email,
    1: setEmail
  } = (0,external_react_.useState)(socialsData.email);
  const {
    0: facebook,
    1: setFacebook
  } = (0,external_react_.useState)(socialsData.facebook);
  const {
    0: twitter,
    1: setTwitter
  } = (0,external_react_.useState)(socialsData.twitter);
  const {
    0: instagram,
    1: setInstagram
  } = (0,external_react_.useState)(socialsData.instagram);
  const {
    0: linkedin,
    1: setLinkedin
  } = (0,external_react_.useState)(socialsData.linkedin);
  const {
    0: youtube,
    1: setYouTube
  } = (0,external_react_.useState)(socialsData.youtube);
  const {
    0: tiktok,
    1: setTiktok
  } = (0,external_react_.useState)(socialsData.tiktok);
  const {
    0: username,
    1: setUsername
  } = (0,external_react_.useState)(profileData.username);
  const {
    0: profileTitle,
    1: setProfileTitle
  } = (0,external_react_.useState)(profileData.profileTitle);
  const {
    0: description,
    1: setDescription
  } = (0,external_react_.useState)(profileData.description);
  const {
    0: avatar,
    1: setAvatar
  } = (0,external_react_.useState)(profileData.avatar);
  const {
    0: cover,
    1: setCover
  } = (0,external_react_.useState)(profileData.cover);
  const {
    0: theme,
    1: setTheme
  } = (0,external_react_.useState)(profileData.theme);
  const {
    0: listLinks,
    1: setListLinks
  } = (0,external_react_.useState)(linksData);
  (0,external_react_.useEffect)(() => {
    getAllLinks();
    getSocials();
    getUserProfile();
  }, [linksData, socialsData, profileData]);

  const getAllLinks = () => {
    //     adminApi.getLinksApi({username:_username}).then((res) => {
    //         if(res.data.success) {
    //             setListLinks(res.data.data)
    //         }
    //    }).catch()
    setListLinks(linksData);
  };

  const getSocials = () => {
    // adminApi.getSocialsApi({username: _username}).then((res) => {
    //     if(res.data.success) {
    setEmail(socialsData.email);
    setFacebook(socialsData.facebook);
    setTwitter(socialsData.twitter);
    setInstagram(socialsData.instagram);
    setLinkedin(socialsData.linkedin);
    setYouTube(socialsData.youtube);
    setTiktok(socialsData.tiktok); //     }
    // }).catch()
  };

  const getUserProfile = () => {
    // authApi.getUserApi({username: _username}).then(res => {
    //     if(res.data.success) {
    setUsername(profileData.username);
    setProfileTitle(profileData.profile_title);
    setDescription(profileData.description);
    setAvatar(profileData.avatar);
    setCover(profileData.cover_image);
    setTheme(profileData.theme); //     }
    // }).catch()
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    id: (index_module_default())[theme],
    className: (my_links_module_default())["page-container"],
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
      children: [/*#__PURE__*/jsx_runtime_.jsx("title", {
        children: profileTitle ? '@' + username + ' - ' + profileTitle + ' | Linktooo' : username
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: "description",
        content: description
      }), /*#__PURE__*/jsx_runtime_.jsx("link", {
        rel: "icon",
        href: HOST + avatar
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "og:title",
        content: profileTitle ? '@' + username + ' - ' + profileTitle + ' | Linktooo' : username
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        property: "og:image",
        content: avatar && avatar != '#' ? HOST + avatar : '/images/avatar-default.jpg'
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: `${(index_module_default())["theme---page-links"]} ${(my_links_module_default())["page-cover"]}`,
      style: cover ? {
        background: `url(${HOST + cover}) no-repeat`,
        backgroundSize: 'cover'
      } : {},
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (my_links_module_default())["page-body"],
        "data-page": "main",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (my_links_module_default())["page-scroll-links"],
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
              className: `${(my_links_module_default())["user-profile_thumb"]} ${(index_module_default())["theme---avatar"]}`,
              children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                src: avatar && avatar != '#' ? HOST + avatar : '/images/avatar-default.jpg',
                alt: "",
                title: ""
              })
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: `${(my_links_module_default())["user-profile__username"]} ${(index_module_default())["user-profile__username"]}`,
              children: ["@", username]
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: `${(my_links_module_default())["user-profile__name"]} ${(index_module_default())["user-profile__username"]}`,
              children: profileTitle ? profileTitle : username
            }), /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: `${(my_links_module_default())["user-profile__description"]} ${(index_module_default())["user-profile__username"]}`,
              children: description
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: `${(my_links_module_default())["list-links"]}`,
            children: listLinks && listLinks.map((link, index) => {
              if (!link.title || !link.url) return;
              return /*#__PURE__*/jsx_runtime_.jsx("a", {
                href: link.url,
                className: `${(my_links_module_default())["links-card"]} ${(index_module_default())["theme---link-card"]} ${(index_module_default())[index % 2 == 0 ? 'theme---card-0' : 'theme---card-1']}`,
                children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: `${(my_links_module_default())["links-card-detail"]} ${(index_module_default())["theme---link-card"]} ${(index_module_default())["theme---link-card-parent"]} ${(index_module_default())[index % 2 == 0 ? 'theme---card-0' : 'theme---card-1']}`,
                  children: [link && link.icon && /*#__PURE__*/jsx_runtime_.jsx("div", {
                    className: `${(my_links_module_default())["img-links"]}`,
                    children: /*#__PURE__*/jsx_runtime_.jsx("img", {
                      src: HOST + link.icon,
                      alt: "",
                      title: "",
                      className: "br-10px"
                    })
                  }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                    className: `${(my_links_module_default())["card-link-url"]} ${(index_module_default())["theme---link-card"]} ${(index_module_default())["theme---link-card-child"]} ${(index_module_default())[index % 2 == 0 ? 'theme---card-0' : 'theme---card-1']}` // style={!cover || cover == '#' ? {color: '#000', backgroundColor: '#e2e2e2'} : {}}
                    ,
                    children: link.title ? link.title : 'Title'
                  })]
                })
              }, link.id);
            })
          })]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        style: {
          height: '100px'
        }
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(Footer, {
        className: `${(my_links_module_default())["footer-links"]}`,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: `${(my_links_module_default())["list-socials"]}`,
          children: [email && /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "mailto:" + email,
            target: "_blank",
            className: `${(index_module_default())["theme---icon-social"]}`,
            children: /*#__PURE__*/jsx_runtime_.jsx((icons_default()), {
              component: () => /*#__PURE__*/(0,jsx_runtime_.jsxs)("svg", {
                viewBox: "0 -4 42 40",
                focusable: "false",
                "data-icon": "tiktok",
                width: "2em",
                height: "2em",
                fill: "currentColor",
                "aria-hidden": "true",
                children: [/*#__PURE__*/jsx_runtime_.jsx("path", {
                  d: "M41.5 35h-40A1.5 1.5 0 010 33.5v-32A1.5 1.5 0 011.5 0h40A1.5 1.5 0 0143 1.5v32a1.5 1.5 0 01-1.5 1.5zM3 32h37V3H3z"
                }), /*#__PURE__*/jsx_runtime_.jsx("path", {
                  d: "M21.5 22a1.494 1.494 0 01-1.033-.412l-20-19A1.5 1.5 0 012.533.413L21.5 18.431 40.467.413a1.5 1.5 0 012.066 2.175l-20 19A1.494 1.494 0 0121.5 22z"
                }), /*#__PURE__*/jsx_runtime_.jsx("path", {
                  d: "M7.61 29.273a1.5 1.5 0 01-1.026-2.595l9.89-9.272a1.5 1.5 0 012.052 2.188l-9.891 9.273a1.494 1.494 0 01-1.025.406zM30.788 24.958a1.5 1.5 0 01-1.026-.406l-5.288-4.958a1.5 1.5 0 112.052-2.188l5.288 4.958a1.5 1.5 0 01-1.026 2.594zM35.39 29.27a1.358 1.358 0 01-.29-.03 2.288 2.288 0 01-.28-.08 2.148 2.148 0 01-.26-.14 2.11 2.11 0 01-.23-.19 1.5 1.5 0 01-.44-1.06 1.516 1.516 0 01.44-1.06 1.3 1.3 0 01.23-.18.939.939 0 01.26-.14 1.309 1.309 0 01.28-.09 1.5 1.5 0 11.29 2.97z"
                })]
              })
            })
          }), facebook && /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: facebook,
            className: `${(index_module_default())["theme---icon-social"]}`,
            children: /*#__PURE__*/jsx_runtime_.jsx((icons_default()), {
              component: () => /*#__PURE__*/(0,jsx_runtime_.jsxs)("svg", {
                viewBox: "0 0 45 40",
                focusable: "false",
                "data-icon": "tiktok",
                width: "2em",
                height: "2em",
                fill: "currentColor",
                "aria-hidden": "true",
                children: [/*#__PURE__*/jsx_runtime_.jsx("path", {
                  d: "M37.5 43h-32A5.507 5.507 0 010 37.5v-32A5.507 5.507 0 015.5 0h32A5.507 5.507 0 0143 5.5v32a5.507 5.507 0 01-5.5 5.5zM5.5 3A2.5 2.5 0 003 5.5v32A2.5 2.5 0 005.5 40h32a2.5 2.5 0 002.5-2.5v-32A2.5 2.5 0 0037.5 3z"
                }), /*#__PURE__*/jsx_runtime_.jsx("path", {
                  d: "M23.5 37.439A1.5 1.5 0 0122.439 37 1.474 1.474 0 0122 35.939a1.371 1.371 0 01.03-.29 2.793 2.793 0 01.079-.29c.04-.089.091-.17.141-.259a2.1 2.1 0 01.189-.22 1.507 1.507 0 011.351-.41.869.869 0 01.279.08 2.225 2.225 0 01.261.139 1.422 1.422 0 01.23.191 2.113 2.113 0 01.19.22c.05.089.1.17.14.259a2.565 2.565 0 01.08.29 1.371 1.371 0 01.03.29A1.517 1.517 0 0124.56 37a1.5 1.5 0 01-1.06.439zM23.5 31.844a1.5 1.5 0 01-1.5-1.5V19.5a9.511 9.511 0 019.5-9.5 1.5 1.5 0 010 3 6.508 6.508 0 00-6.5 6.5v10.844a1.5 1.5 0 01-1.5 1.5z"
                }), /*#__PURE__*/jsx_runtime_.jsx("path", {
                  d: "M31.5 26h-12a1.5 1.5 0 010-3h12a1.5 1.5 0 010 3z"
                })]
              })
            })
          }), youtube && /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: youtube,
            className: `${(index_module_default())["theme---icon-social"]}`,
            children: /*#__PURE__*/jsx_runtime_.jsx(icons_namespaceObject.YoutubeOutlined, {
              className: "custom-icon",
              style: {
                fontSize: '32px'
              }
            })
          }), twitter && /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: twitter,
            className: `${(index_module_default())["theme---icon-social"]}`,
            children: /*#__PURE__*/jsx_runtime_.jsx((icons_default()), {
              component: () => /*#__PURE__*/(0,jsx_runtime_.jsxs)("svg", {
                viewBox: "0 -4 42 40",
                focusable: "false",
                "data-icon": "tiktok",
                width: "2em",
                height: "2em",
                fill: "currentColor",
                "aria-hidden": "true",
                children: [/*#__PURE__*/jsx_runtime_.jsx("path", {
                  d: "M12.466 40.187a1.5 1.5 0 01-1.061-.44 1.5 1.5 0 010-2.119 1.547 1.547 0 012.121 0 1.481 1.481 0 01.44 1.059 1.519 1.519 0 01-.44 1.06 1.5 1.5 0 01-1.06.44z"
                }), /*#__PURE__*/jsx_runtime_.jsx("path", {
                  d: "M19.063 39.78a1.5 1.5 0 01-.226-2.982c8-1.23 14.361-5.269 17.018-10.806a21.785 21.785 0 00.463-16.676c-1.186-3-2.963-5.087-5-5.879a7.409 7.409 0 00-7.731 1.681c-1.964 2.117-2.325 5.555-.921 8.758a1.5 1.5 0 01-1.59 2.087 37.749 37.749 0 01-12.387-4.045 37.04 37.04 0 01-5.633-3.709c-.273 4.029.12 11.367 5.34 17.455a22.116 22.116 0 005.769 4.767 1.5 1.5 0 01.139 2.512 51.008 51.008 0 01-10.758 5.782 1.5 1.5 0 11-1.135-2.777 52.857 52.857 0 008.283-4.176 25.014 25.014 0 01-4.574-4.154C-1.64 18.568.023 7.165.435 4.971a1.5 1.5 0 012.492-.825A34.611 34.611 0 0010.1 9.272a34.421 34.421 0 009 3.287 10.567 10.567 0 012.288-9.482A10.411 10.411 0 0132.4.64c2.827 1.1 5.209 3.788 6.706 7.573a24.925 24.925 0 01-.548 19.076c-3.084 6.431-10.286 11.094-19.265 12.474a1.629 1.629 0 01-.23.017z"
                }), /*#__PURE__*/jsx_runtime_.jsx("path", {
                  d: "M13.138 26.085a16.891 16.891 0 01-1.757-.091 20.7 20.7 0 01-7.657-2.605 1.5 1.5 0 011.523-2.584 17.493 17.493 0 006.445 2.205 14.044 14.044 0 002.9 0 1.5 1.5 0 11.307 2.984 16.949 16.949 0 01-1.761.091zM38.077 11.275a1.483 1.483 0 01-.778-.219 1.5 1.5 0 01-.5-2.061L37.948 7.1l-1.712.114a1.5 1.5 0 01-.2-2.995l4.594-.3A1.5 1.5 0 0142.012 6.2l-2.652 4.355a1.5 1.5 0 01-1.283.72z"
                })]
              })
            })
          }), instagram && /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: instagram,
            className: `${(index_module_default())["theme---icon-social"]}`,
            children: /*#__PURE__*/jsx_runtime_.jsx((icons_default()), {
              component: () => /*#__PURE__*/(0,jsx_runtime_.jsxs)("svg", {
                viewBox: "0 0 43 40",
                focusable: "false",
                "data-icon": "tiktok",
                width: "2em",
                height: "2em",
                fill: "currentColor",
                "aria-hidden": "true",
                children: [/*#__PURE__*/jsx_runtime_.jsx("path", {
                  d: "M41.5 28.5a1.558 1.558 0 01-.57-.11 1.527 1.527 0 01-.491-.33 1.5 1.5 0 010-2.121 1.566 1.566 0 01.231-.189 2.153 2.153 0 01.26-.141 2.423 2.423 0 01.28-.079 1.5 1.5 0 11.29 2.97z"
                }), /*#__PURE__*/jsx_runtime_.jsx("path", {
                  d: "M33.5 43h-24A9.511 9.511 0 010 33.5v-24A9.511 9.511 0 019.5 0h24A9.511 9.511 0 0143 9.5v11.208a1.5 1.5 0 01-3 0V9.5A6.508 6.508 0 0033.5 3h-24A6.508 6.508 0 003 9.5v24A6.508 6.508 0 009.5 40h24a6.508 6.508 0 006.5-6.5 1.5 1.5 0 013 0 9.511 9.511 0 01-9.5 9.5z"
                }), /*#__PURE__*/jsx_runtime_.jsx("path", {
                  d: "M21.5 33A11.5 11.5 0 1133 21.5 11.513 11.513 0 0121.5 33zm0-20a8.5 8.5 0 108.5 8.5 8.51 8.51 0 00-8.5-8.5zM34 12a2 2 0 112-2 2 2 0 01-2 2zm0-3a1 1 0 101 1 1 1 0 00-1-1z"
                })]
              })
            })
          }), tiktok && /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: tiktok,
            className: `${(index_module_default())["theme---icon-social"]}`,
            children: /*#__PURE__*/jsx_runtime_.jsx((icons_default()), {
              component: () => /*#__PURE__*/jsx_runtime_.jsx("svg", {
                viewBox: "-32 0 512 512",
                focusable: "false",
                "data-icon": "tiktok",
                width: "2em",
                height: "2em",
                fill: "currentColor",
                "aria-hidden": "true",
                children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                  xmlns: "http://www.w3.org/2000/svg",
                  d: "m432.734375 112.464844c-53.742187 0-97.464844-43.722656-97.464844-97.464844 0-8.285156-6.71875-15-15-15h-80.335937c-8.285156 0-15 6.714844-15 15v329.367188c0 31.59375-25.703125 57.296874-57.300782 57.296874-31.59375 0-57.296874-25.703124-57.296874-57.296874 0-31.597657 25.703124-57.300782 57.296874-57.300782 8.285157 0 15-6.714844 15-15v-80.335937c0-8.28125-6.714843-15-15-15-92.433593 0-167.632812 75.203125-167.632812 167.636719 0 92.433593 75.199219 167.632812 167.632812 167.632812 92.433594 0 167.636719-75.199219 167.636719-167.632812v-145.792969c29.855469 15.917969 63.074219 24.226562 97.464844 24.226562 8.285156 0 15-6.714843 15-15v-80.335937c0-8.28125-6.714844-15-15-15zm-15 79.714844c-32.023437-2.664063-62.433594-13.851563-88.707031-32.75-4.566406-3.289063-10.589844-3.742188-15.601563-1.171876-5.007812 2.5625-8.15625 7.71875-8.15625 13.347657v172.761719c0 75.890624-61.746093 137.632812-137.636719 137.632812-75.890624 0-137.632812-61.742188-137.632812-137.632812 0-70.824219 53.773438-129.328126 122.632812-136.824219v50.8125c-41.015624 7.132812-72.296874 42.984375-72.296874 86.011719 0 48.136718 39.160156 87.300781 87.296874 87.300781 48.140626 0 87.300782-39.164063 87.300782-87.300781v-314.367188h51.210937c6.871094 58.320312 53.269531 104.71875 111.589844 111.589844zm0 0"
                })
              })
            })
          }), /*#__PURE__*/jsx_runtime_.jsx((icons_default()), {
            type: "home"
          }), linkedin && /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: linkedin,
            className: `${(index_module_default())["theme---icon-social"]}`,
            children: /*#__PURE__*/jsx_runtime_.jsx(icons_namespaceObject.LinkedinOutlined, {
              className: "custom-icon",
              style: {
                fontSize: '32px'
              }
            })
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("a", {
          href: "/",
          className: `${(index_module_default())["theme---footer"]} ${(my_links_module_default())["footer-logo"]}`,
          children: /*#__PURE__*/jsx_runtime_.jsx("img", {
            className: (my_links_module_default())["logo-footer"],
            src: "/images/logo-linktooo.png"
          })
        })]
      })]
    })]
  });
};
// EXTERNAL MODULE: ./src/api/http.js
var http = __webpack_require__(2599);
;// CONCATENATED MODULE: ./src/api/adminApi.js

/* harmony default export */ const adminApi = ({
  addLinkApi: data => {
    return (0,http/* authHttp */.D)().post('api/add-links', data);
  },
  getAllLinksApi: () => {
    return (0,http/* authHttp */.D)().get('api/get-all-links');
  },
  getLinksApi: data => {
    return http/* http.post */.d.post('api/get-links', data);
  },
  updateLinksApi: data => {
    return (0,http/* authHttp */.D)().post('api/update-links', data);
  },
  updateProfileApi: data => {
    return (0,http/* authHttp */.D)().post('api/update-profile', data);
  },
  updateSocialsApi: data => {
    return (0,http/* authHttp */.D)().post('api/update-socials', data);
  },
  getAllSocialsApi: () => {
    return (0,http/* authHttp */.D)().post('api/get-all-socials');
  },
  getSocialsApi: data => {
    return http/* http.post */.d.post('api/get-socials', data);
  },
  removeLinkApi: data => {
    return (0,http/* authHttp */.D)().post('api/remove-links', data);
  },
  updateThumbnailApi: data => {
    return (0,http/* authHttp */.D)().post('api/change-thumbnail', data);
  },
  updateAvtApi: data => {
    return (0,http/* authHttp */.D)().post('api/update-avatar', data);
  },
  updateCoverApi: data => {
    return (0,http/* authHttp */.D)().post('api/update-cover', data);
  },
  getAllThemesApi: () => {
    return (0,http/* authHttp */.D)().get('api/get-themes');
  },
  changeThemeApi: data => {
    return (0,http/* authHttp */.D)().post('api/change-theme', data);
  }
});
// EXTERNAL MODULE: ./src/api/authApi.js
var authApi = __webpack_require__(1606);
;// CONCATENATED MODULE: ./pages/my/[username].tsx






const MyLinks = ({
  linksData,
  socialsData,
  profileData
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx((external_react_default()).Fragment, {
    children: /*#__PURE__*/jsx_runtime_.jsx(MyLinksTemplate, {
      linksData: linksData,
      socialsData: socialsData,
      profileData: profileData
    })
  });
};

async function getStaticProps({
  params
}) {
  const linksData = await adminApi.getLinksApi({
    username: params.username
  }).then(res => {
    if (res.data.success) {
      return res.data.data;
    } else return [];
  }).catch();
  const socialsData = await adminApi.getSocialsApi({
    username: params.username
  }).then(res => {
    if (res.data.success) {
      return res.data.data;
    } else return [];
  }).catch();
  const profileData = await authApi/* default.getUserApi */.Z.getUserApi({
    username: params.username
  }).then(res => {
    if (res.data.success) {
      console.log(1);
      return res.data.data;
    } else return null;
  }).catch();
  console.log(2);
  return {
    props: {
      linksData,
      socialsData,
      profileData
    }
  };
}
async function getStaticPaths() {
  return {
    paths: [1].map(() => ({
      params: {
        username: 'user1'
      }
    })),
    //indicates that no page needs be created at build time
    fallback: 'blocking' //indicates the type of fallback

  };
} // export const getServerSideProps = async ({ locale }:any) => ({
//   props: {
//     ...(await serverSideTranslations(locale, ["common"])),
//   },
// });

/* harmony default export */ const _username_ = (MyLinks);

/***/ }),

/***/ 9349:
/***/ ((module) => {

// Exports
module.exports = {
	"page-container": "my-links_page-container__18Mv2",
	"page-cover": "my-links_page-cover__VAG26",
	"page-body": "my-links_page-body__ggNiW",
	"page-scroll-links": "my-links_page-scroll-links__28laA",
	"user-profile_thumb": "my-links_user-profile_thumb__3ZH_V",
	"user-profile__username": "my-links_user-profile__username__2N5KC",
	"user-profile__name": "my-links_user-profile__name__22AAX",
	"user-profile__description": "my-links_user-profile__description__2Fk8p",
	"list-links": "my-links_list-links__fKFNG",
	"links-card": "my-links_links-card__3grdf",
	"links-card-detail": "my-links_links-card-detail__1YPap",
	"img-links": "my-links_img-links__vd58E",
	"card-link-url": "my-links_card-link-url__kAB52",
	"footer-links": "my-links_footer-links__1ruRK",
	"list-socials": "my-links_list-socials__36gKs",
	"footer-logo": "my-links_footer-logo__3ckkO",
	"logo-footer": "my-links_logo-footer__268BJ"
};


/***/ }),

/***/ 2122:
/***/ ((module) => {

// Exports
module.exports = {
	"theme1": "themes_theme1__OesV4",
	"theme---background-image-page": "themes_theme---background-image-page__3V6n5",
	"theme---page-links": "themes_theme---page-links__15FGw",
	"theme---header": "themes_theme---header__25dTC",
	"theme---add-new-link": "themes_theme---add-new-link__Yydhl",
	"theme---switch": "themes_theme---switch__1Dw_G",
	"theme---card-link-admin": "themes_theme---card-link-admin__BGqKe",
	"theme---buttom-edit": "themes_theme---buttom-edit__3xjCQ",
	"theme---title-input": "themes_theme---title-input__3YCoU",
	"theme---sub-menu-header": "themes_theme---sub-menu-header__3ra-k",
	"theme---button-primary": "themes_theme---button-primary__1mZ89",
	"theme---sub-menu-body": "themes_theme---sub-menu-body__3G5HI",
	"theme---close-button": "themes_theme---close-button__3kn6D",
	"theme---link-card-child": "themes_theme---link-card-child__1gkAB",
	"theme---link-card": "themes_theme---link-card__3MQvI",
	"theme---footer": "themes_theme---footer__1ItFM",
	"theme---admin-footer": "themes_theme---admin-footer__1X0Pd",
	"theme---button-remove": "themes_theme---button-remove__1ngXI",
	"theme---button-danger": "themes_theme---button-danger__gVSQE",
	"selected": "themes_selected__2FLbv",
	"theme---social-edit-form": "themes_theme---social-edit-form__2Dej7",
	"socials-label": "themes_socials-label__F8yQX",
	"theme---profile-edit": "themes_theme---profile-edit__2A_66",
	"profile-title": "themes_profile-title__27uB1",
	"theme---link-admin": "themes_theme---link-admin__1k4lL",
	"theme---icon-social": "themes_theme---icon-social__3KQE3",
	"button-theme": "themes_button-theme__32bJj",
	"active": "themes_active__9p_1_",
	"theme---avatar": "themes_theme---avatar__31bfw",
	"theme2": "themes_theme2__11JKH",
	"theme3": "themes_theme3__2YLS0",
	"theme4": "themes_theme4__1BdnU",
	"theme5": "themes_theme5__2asLF",
	"test": "themes_test__2yjo8",
	"user-profile__name": "themes_user-profile__name__1jUrV",
	"user-profile__username": "themes_user-profile__username__143JI",
	"description-custom": "themes_description-custom__HkngL",
	"theme---admin-content": "themes_theme---admin-content__5N6H7",
	"theme---menu": "themes_theme---menu__1ykER",
	"theme---button-cancel": "themes_theme---button-cancel__3Zbvv",
	"theme_canvas_1": "themes_theme_canvas_1__vTQxY",
	"theme_canvas_2": "themes_theme_canvas_2__3oxcW",
	"theme_canvas_3": "themes_theme_canvas_3__179iD",
	"theme---card-0": "themes_theme---card-0__1_n_O",
	"theme---card-1": "themes_theme---card-1__WToCd",
	"theme_canvas_4": "themes_theme_canvas_4__3ixWt",
	"theme_canvas_5": "themes_theme_canvas_5__3fhVr",
	"theme---link-card-parent": "themes_theme---link-card-parent__2PXoh",
	"theme_canvas_6": "themes_theme_canvas_6__10h9V",
	"theme_canvas_7": "themes_theme_canvas_7__1U_FP",
	"theme_canvas_8": "themes_theme_canvas_8__2Fyz1",
	"theme---admin-card-0": "themes_theme---admin-card-0__1yJoX",
	"theme---admin-card-1": "themes_theme---admin-card-1__3uaqq",
	"theme_canvas_9": "themes_theme_canvas_9__iOeop",
	"theme_canvas_10": "themes_theme_canvas_10__Vsfi4",
	"theme_canvas_11": "themes_theme_canvas_11__xEghs",
	"theme_canvas_12": "themes_theme_canvas_12__1ioIn",
	"theme_canvas_13": "themes_theme_canvas_13__1Fqar",
	"theme_canvas_14": "themes_theme_canvas_14__3gIP6",
	"theme_canvas_15": "themes_theme_canvas_15__22qdS",
	"theme_coach_for_life": "themes_theme_coach_for_life__3UnZ_",
	"theme---submenu": "themes_theme---submenu__2DTAy",
	"theme_vci_coach": "themes_theme_vci_coach__2FENQ",
	"page": "themes_page__2CqhE"
};


/***/ }),

/***/ 953:
/***/ ((module) => {

"use strict";
module.exports = require("antd");

/***/ }),

/***/ 2376:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 8475:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next");

/***/ }),

/***/ 701:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 9297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 5282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 8993:
/***/ ((module) => {

"use strict";
module.exports = require("universal-cookie");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [606], () => (__webpack_exec__(629)));
module.exports = __webpack_exports__;

})();