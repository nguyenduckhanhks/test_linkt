"use strict";
exports.id = 606;
exports.ids = [606];
exports.modules = {

/***/ 1606:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2599);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  loginApi: data => {
    return _http__WEBPACK_IMPORTED_MODULE_0__/* .http.post */ .d.post('/api/admin/login', data);
  },
  logoutApi: () => {
    return (0,_http__WEBPACK_IMPORTED_MODULE_0__/* .authHttp */ .D)().post('api/admin/logout');
  },
  signupApi: data => {
    return _http__WEBPACK_IMPORTED_MODULE_0__/* .http.post */ .d.post('api/admin/signup', data);
  },
  getProfileApi: () => {
    return (0,_http__WEBPACK_IMPORTED_MODULE_0__/* .authHttp */ .D)().get('api/admin/get-profile');
  },
  getUserApi: data => {
    return _http__WEBPACK_IMPORTED_MODULE_0__/* .http.post */ .d.post('api/admin/get-user', data);
  }
});

/***/ }),

/***/ 2599:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "d": () => (/* binding */ http),
/* harmony export */   "D": () => (/* binding */ authHttp)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2376);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_cookies__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5315);


const HOST = "https://linkt.ooo/";
const http = axios__WEBPACK_IMPORTED_MODULE_0___default().create({
  baseURL: HOST
});
const authHttp = () => {
  const ACCESS_TOKEN = _services_cookies__WEBPACK_IMPORTED_MODULE_1__/* .default.get */ .Z.get('access_token') ? _services_cookies__WEBPACK_IMPORTED_MODULE_1__/* .default.get */ .Z.get('access_token') : '';
  const TOKEN_TYPE = _services_cookies__WEBPACK_IMPORTED_MODULE_1__/* .default.get */ .Z.get('token_type') ? _services_cookies__WEBPACK_IMPORTED_MODULE_1__/* .default.get */ .Z.get('token_type') : '';
  return axios__WEBPACK_IMPORTED_MODULE_0___default().create({
    baseURL: HOST,
    headers: {
      'Authorization': `${TOKEN_TYPE} ${ACCESS_TOKEN}`
    }
  });
};

/***/ }),

/***/ 5315:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8993);
/* harmony import */ var universal_cookie__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(universal_cookie__WEBPACK_IMPORTED_MODULE_0__);

const cookie = new (universal_cookie__WEBPACK_IMPORTED_MODULE_0___default())();

class CookieService {
  get(key) {
    return cookie.get(key);
  }

  set(key, value, options = {
    path: '/'
  }) {
    cookie.set(key, value, options);
  }

  remove(key) {
    cookie.remove(key);
  }

}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (new CookieService());

/***/ })

};
;